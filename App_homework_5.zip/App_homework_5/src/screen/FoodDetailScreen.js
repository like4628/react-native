import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, TextInput, TouchableOpacity, TouchableHighlight, Image, ShadowPropTypesIOS } from 'react-native';

export default function FoodDetailScreen(props) {




    return (
        <View style={styles.container}>
            {/* 上課練習開始 */}
            {/* <Text>MemoDetailScreen</Text>
            <Button
                title=' go to Memo screen'
                onPress={() => props.navigation.pop()}></Button> */}
            {/* 接收值 */}
            {/* <Text>{props.route.params.name || 'nothing'}</Text>
            <Button
                title='change memo food'
                onPress={() => props.route.params.functionOne('Apple')}></Button> */}

            {/* 上課練習結束 */}

            {/* 作業開始 */}
            <Image
                style={styles.pic}
                source={{ uri: 'https://www.gomaji.com/blog/wp-content/uploads/2020/01/food-3676796_1280.jpg' }}></Image>
            <Image
                style={styles.pic}
                source={{ uri: 'https://1.bp.blogspot.com/-v4zsx3k_hNg/XKuWeKy93hI/AAAAAAAAEm8/64POlrZnAuwppS0CjlnuAmwrmrkOW4kiQCLcBGAs/s1600/Taiwanese%2BBeef%2BNoodles-15.jpg' }}></Image>
            <Image
                style={styles.pic}
                source={{ uri: 'https://www.teepr.com/wp-content/uploads/2017/10/large_c7fafea053883145.jpg' }}></Image>

            {/* 作業結束 */}
        </View >

    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: "column",
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    // 作業開始
    pic: {
        width: '100%',
        height: '33.3333%',
        resizeMode: 'cover'
    }
    // 作業結束
});
