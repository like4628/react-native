import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, TextInput, TouchableOpacity, TouchableHighlight, Image, Dimensions, ImageBackground } from 'react-native';



export default function Dessert(props) {


    const printMessage = () => {
        console.log('成功了 按到按鈕了')
    }


    return (
        <View style={styles.container}>
            <ImageBackground style={styles.bg} source={{ uri: 'https://png.pngtree.com/thumb_back/fw800/back_our/20190620/ourmid/pngtree-afternoon-tea-display-rack-background-material-image_146857.jpg' }}></ImageBackground>
            <Text style={styles.Title}>甜點區</Text>
            <TouchableOpacity
                style={styles.nextPage}
                onPress={() => props.navigation.push('DessertScreen')}
            ><Text style={{ fontSize: 20, color: '#fff', color: 'pink' }}>點我進入甜點世界</Text></TouchableOpacity>
        </View >

    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    bg: {
        width: '100%',
        height: '100%',
        zIndex: -10,
    },
    nextPage: {
        width: 200,
        height: 50,
        position: 'absolute',
        fontSize: 40,
        backgroundColor: 'black',
        // borderColor: 'red',
        // borderWidth: 4,
        borderRadius: 10,
        alignItems: 'center',
        paddingVertical: 10
    },
    Title: {
        position: 'absolute',
        fontSize: 40,
        top: 250

    }

});
