import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, TextInput, TouchableOpacity, TouchableHighlight, Image, ShadowPropTypesIOS } from 'react-native';

export default function Food(props) {



    const [food, setFood] = useState('candy')
    const changeFood = (foodGet) => {
        setFood(foodGet)
    }


    return (
        <View style={styles.container}>
            {/* 上課開始 */}

            {/* <Text>Memo</Text>
            <Text>{food}</Text>
            <Button
                title='下一頁'
                //push內填的是該頁的名字name後面的，不是此檔案名字
                //如果要傳值就逗號後面大括號
                onPress={() => props.navigation.push('MemoDetail', { name: 'Nash', functionOne: (arg) => changeFood(arg) })} ></Button>  */}

            {/* 上課結束 */}

            {/* 作業開始 */}

            <Image style={styles.bg} source={{ uri: 'https://png.pngtree.com/thumb_back/fw800/back_our/20190620/ourmid/pngtree-cartoon-gourmet-table-restaurant-yellow-background-image_159224.jpg' }}></Image>
            <Text style={styles.Title}>美食區</Text>
            <TouchableOpacity
                style={styles.nextPage}
                onPress={() => props.navigation.push('FoodDetailScreen')}>
                <Text style={{ fontSize: 20, color: '#fff', color: 'pink' }}>點我進入美食世界</Text>
            </TouchableOpacity>

            {/* 作業結束 */}

        </View >

    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    // 作業開始
    bg: {
        width: '100%',
        height: '100%',
        zIndex: -10,
    },
    nextPage: {
        width: 200,
        height: 50,
        position: 'absolute',
        fontSize: 40,
        backgroundColor: 'black',
        // borderColor: 'red',
        // borderWidth: 4,
        borderRadius: 10,
        alignItems: 'center',
        paddingVertical: 10
    },
    Title: {
        position: 'absolute',
        fontSize: 40,
        top: 250

    }
    // 作業結束
});
