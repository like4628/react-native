import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, TextInput, TouchableOpacity, TouchableHighlight, Image, ShadowPropTypesIOS } from 'react-native';

export default function DessertScreen(props) {

    return (
        <View style={styles.container}>
            {/* 上課開始 */}

            {/* <Button
                title='上一頁'
                //返回上一頁
                onPress={() => props.navigation.pop()}></Button> */}

            {/* 上課結束 */}

            {/* 作業開始 */}

            <Image
                style={styles.pic}
                source={{ uri: 'https://images.chinatimes.com/newsphoto/2019-09-22/900/20190922001357.jpg' }}></Image>
            <Image
                style={styles.pic}
                source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSmiuLpcB2y4k5QwpSzwchS6xjK-S5XBq0hxOtLQPTNp5q1N57I&usqp=CAU' }}></Image>
            <Image
                style={styles.pic}
                source={{ uri: 'https://www.ellie.com.tw/images/cake/2-cake-02.jpg' }}></Image>
            {/* 作業結束 */}
        </View >

    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: "column",
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    // 作業開始    
    pic: {
        width: '100%',
        height: '33.3333%',
        resizeMode: 'cover'
    }
    // 作業結束

});
